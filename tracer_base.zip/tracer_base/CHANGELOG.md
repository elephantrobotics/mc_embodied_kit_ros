# Changelog for package scout_base

## 0.0.2 (2019-06-14)
------------------
* Deprecated initial serial interface support (new one under development)
* Based on Scout SDK v0.2 with CAN interface 
* Contributors: Ruixiang Du
  
## 0.0.1 (2019-05-08)
------------------
* Initial development of scout_base for Scout
* Contributors: Ruixiang Du
