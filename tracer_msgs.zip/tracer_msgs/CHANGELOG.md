# Changelog for package scout_msgs

## 0.0.1 (2019-06-14)
------------------
* Initial development of tracer_msgs for Scout
* Contributors: Ruixiang Du,Peisen Zhou
